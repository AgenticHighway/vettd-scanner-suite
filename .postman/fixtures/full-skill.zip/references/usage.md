# Usage

1. Invoke `scripts/run.sh` from the skill root.
2. Optionally call `scripts/helper.py` for the greeting helper.

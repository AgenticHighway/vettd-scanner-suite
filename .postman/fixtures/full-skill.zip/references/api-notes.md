# API Notes

This skill fixture makes no network calls and has no external dependencies.
It exists solely as realistic zip content for API smoke tests.

---
name: example-full-skill
description: Example skill with scripts and references, used to smoke-test the scanner suite's upload endpoint.
version: 1.0.0
allowed-tools: ["bash", "python"]
---

# Example Full Skill

Demonstrates a more realistic skill layout: frontmatter, a couple of helper
scripts, and reference docs. Used purely as Postman fixture content — it does
not perform any real action.

## Usage

Run `scripts/run.sh` to execute the skill's main entry point. See
`references/usage.md` for details.

#!/usr/bin/env bash
set -euo pipefail
echo "example-full-skill: hello from run.sh"

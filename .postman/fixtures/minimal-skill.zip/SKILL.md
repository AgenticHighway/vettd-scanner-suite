---
name: example-minimal-skill
description: Minimal example skill used to smoke-test the scanner suite's upload endpoint.
version: 1.0.0
---

# Example Minimal Skill

A minimal, single-file skill fixture for Postman smoke tests.
